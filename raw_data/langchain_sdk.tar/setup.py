
from setuptools import setup, find_packages

setup(
    name='langchain',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'pandas',
        # Add other dependencies here
    ],
    author='Your Name',
    author_email='your.email@example.com',
    description='LangChain SDK for data processing and insights',
    license='MIT',
    keywords='langchain data insights',
    url='https://github.com/your_github/langchain_sdk'  # replace with your actual GitHub URL
)
